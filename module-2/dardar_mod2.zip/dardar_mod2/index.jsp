<%--
    Name: Jordan Dardar
    Date: 06/09/2026
    Assignment: CSD430 Module 2.2 Programming Assignment
    Purpose: This JSP page uses scriptlets to create dynamic table data for places I have enjoyed visiting.
    Source: Original work created for this assignment with AI assistance used for formatting and structure.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    /*
        The following Java arrays hold the dynamic data that will be displayed in the HTML table.
        Each record includes three fields: place, category, and description.
    */
    String[][] places = {
            {"Panama City Beach, Florida", "Beach Trip", "A relaxing place with clear water, beaches, and family-friendly activities."},
            {"Branson, Missouri", "Vacation Spot", "A fun city with shows, attractions, shopping, and outdoor activities."},
            {"Dallas, Texas", "City Trip", "A large city with great restaurants, sports, shopping, and entertainment."},
            {"Hot Springs, Arkansas", "State Visit", "A historic Arkansas city known for bathhouses, hiking, and scenic views."},
            {"Tulsa, Oklahoma", "Weekend Trip", "A nearby city with museums, food, parks, and live events."}
    };

    /*
        These variables provide summary information for the page.
    */
    String pageTitle = "Places I Have Enjoyed Visiting";
    String topicDescription = "This page displays a list of states and cities I have enjoyed visiting. "
            + "The data is grouped by travel category and displayed using a dynamic JSP table.";
    int recordCount = places.length;
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><%= pageTitle %></title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>

<body>
<div class="container">
    <header>
        <h1><%= pageTitle %></h1>
        <p><%= topicDescription %></p>
    </header>

    <section class="summary">
        <h2>Overall Data Description</h2>
        <p>
            This table contains <%= recordCount %> travel records. Each record includes
            the location name, the category of trip, and a short description of why the
            location was enjoyable.
        </p>
    </section>

    <section>
        <h2>Travel Records</h2>

        <table>
            <thead>
            <tr>
                <th>Location</th>
                <th>Category</th>
                <th>Description</th>
            </tr>
            </thead>

            <tbody>
            <%
                /*
                    This loop creates one table row for each record in the places array.
                */
                for (int i = 0; i < places.length; i++) {
            %>
            <tr>
                <td><%= places[i][0] %></td>
                <td><%= places[i][1] %></td>
                <td><%= places[i][2] %></td>
            </tr>
            <%
                }
            %>
            </tbody>
        </table>
    </section>

    <footer>
        <p>CSD430 Module 2.2 JSP Scriptlet Assignment</p>
    </footer>
</div>
</body>
</html>
