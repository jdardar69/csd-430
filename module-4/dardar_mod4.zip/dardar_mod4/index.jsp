<%@ page import="com.dardar.Game" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    Game game1 = new Game("Call of Duty: Black Ops 6", "PlayStation 5", "First-Person Shooter", "2024", "Mature");
    Game game2 = new Game("Madden NFL 25", "PlayStation 5", "Sports", "2024", "Everyone");
    Game game3 = new Game("Minecraft", "PC", "Sandbox", "2011", "Everyone 10+");
    Game game4 = new Game("Grand Theft Auto V", "PlayStation 5", "Action/Adventure", "2013", "Mature");
    Game game5 = new Game("Fortnite", "Cross-Platform", "Battle Royale", "2017", "Teen");

    Game[] games = {game1, game2, game3, game4, game5};
%>

<!DOCTYPE html>
<html>
<head>
    <title>Jordan Dardar Module 4.2 JavaBean Assignment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            margin: 40px;
        }

        h1 {
            color: #222;
            text-align: center;
        }

        .description {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 12px;
            text-align: left;
        }

        td {
            border: 1px solid #ccc;
            padding: 10px;
        }

        tr:nth-child(even) {
            background-color: #eef3f7;
        }

        .footer {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
        }
    </style>
</head>
<body>

<h1>Favorite Video Game Data Display</h1>

<div class="description">
    <h2>Assignment Description</h2>
    <p>
        This JSP page uses a JavaBean to store and display data in an HTML table.
        The JavaBean contains five fields: title, platform, genre, release year, and rating.
        Scriptlets are used to create the JavaBean objects, while all HTML tags remain outside
        of the Java scriptlet code.
    </p>
</div>

<table>
    <tr>
        <th>Game Title</th>
        <th>Platform</th>
        <th>Genre</th>
        <th>Release Year</th>
        <th>Rating</th>
    </tr>

    <%
        for (Game game : games) {
    %>
    <tr>
        <td><%= game.getTitle() %></td>
        <td><%= game.getPlatform() %></td>
        <td><%= game.getGenre() %></td>
        <td><%= game.getReleaseYear() %></td>
        <td><%= game.getRating() %></td>
    </tr>
    <%
        }
    %>
</table>

<div class="footer">
    <p>Jordan Dardar | CSD430 Server Side Development | Module 4.2</p>
</div>

</body>
</html>