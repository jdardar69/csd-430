<%@ page import="java.time.LocalDateTime" %>
<%@ page import="java.time.format.DateTimeFormatter" %>

<!DOCTYPE html>
<html>
<head>
    <title>Jordan Dardar Module 1.3 JSP</title>
</head>
<body>
    <h1>Module 1.3 JSP Assignment</h1>

    <p>Name: Jordan Dardar</p>
    <p>Course: CSD430 Server Side Development</p>
    <p>Assignment: Module 1.3 Programming Assignment</p>

    <%
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
        String currentTime = now.format(formatter);
    %>

    <p>The current server date and time is:</p>
    <h2><%= currentTime %></h2>
</body>
</html>