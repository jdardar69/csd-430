<%--
    Jordan Dardar
    CSD430 Server Side Development
    Module 3.2 Programming Assignment
    Purpose: This JSP form collects yearly vehicle review information from a user.
--%>

<!DOCTYPE html>
<html>
<head>
    <title>Yearly Vehicle Review Form</title>
</head>
<body>

<h1>Yearly Vehicle Review Form</h1>

<p>
    This form collects information for a yearly review of a vehicle purchase.
    Please enter the requested information below and submit the form.
</p>

<form action="display.jsp" method="post">

    <label>Customer Name:</label><br>
    <input type="text" name="customerName" required><br><br>

    <label>Vehicle Make:</label><br>
    <input type="text" name="vehicleMake" required><br><br>

    <label>Vehicle Model:</label><br>
    <input type="text" name="vehicleModel" required><br><br>

    <label>Year Purchased:</label><br>
    <input type="number" name="yearPurchased" required><br><br>

    <label>Overall Rating:</label><br>
    <select name="rating" required>
        <option value="">Select a rating</option>
        <option value="Excellent">Excellent</option>
        <option value="Good">Good</option>
        <option value="Average">Average</option>
        <option value="Poor">Poor</option>
    </select><br><br>

    <label>Would Recommend:</label><br>
    <input type="radio" name="recommend" value="Yes" required> Yes
    <input type="radio" name="recommend" value="No"> No<br><br>

    <label>Review Comments:</label><br>
    <textarea name="comments" rows="5" cols="40" required></textarea><br><br>

    <input type="submit" value="Submit Review">

</form>

</body>
</html>