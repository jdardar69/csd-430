<%--
    Jordan Dardar
    CSD430 Server Side Development
    Module 3.2 Programming Assignment
    Purpose: This JSP page receives form data and displays it in an HTML table.
--%>

<%
    String customerName = request.getParameter("customerName");
    String vehicleMake = request.getParameter("vehicleMake");
    String vehicleModel = request.getParameter("vehicleModel");
    String yearPurchased = request.getParameter("yearPurchased");
    String rating = request.getParameter("rating");
    String recommend = request.getParameter("recommend");
    String comments = request.getParameter("comments");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Review Results</title>
</head>
<body>

<h1>Vehicle Review Results</h1>

<p>
    The table below displays the yearly vehicle review information submitted by the user.
</p>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Field Description</th>
        <th>Submitted Data</th>
    </tr>
    <tr>
        <td>Customer Name</td>
        <td><%= customerName %></td>
    </tr>
    <tr>
        <td>Vehicle Make</td>
        <td><%= vehicleMake %></td>
    </tr>
    <tr>
        <td>Vehicle Model</td>
        <td><%= vehicleModel %></td>
    </tr>
    <tr>
        <td>Year Purchased</td>
        <td><%= yearPurchased %></td>
    </tr>
    <tr>
        <td>Overall Rating</td>
        <td><%= rating %></td>
    </tr>
    <tr>
        <td>Would Recommend</td>
        <td><%= recommend %></td>
    </tr>
    <tr>
        <td>Review Comments</td>
        <td><%= comments %></td>
    </tr>
</table>

<br>

<a href="form.jsp">Return to Form</a>

</body>
</html>